# AutoRAG starter kit

Minimal fixture for download integration tests.
