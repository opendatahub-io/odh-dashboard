export * from './compiled-types/src/odh/extension-points/index';
export { default } from './compiled-types/src/odh/extension-points/index';