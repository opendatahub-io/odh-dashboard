import { UserSettings } from 'mod-arch-core';
declare const useUser: () => UserSettings;
export default useUser;
