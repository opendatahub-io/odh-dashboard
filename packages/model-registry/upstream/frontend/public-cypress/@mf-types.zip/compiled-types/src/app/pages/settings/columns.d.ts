import { SortableData, ModelRegistryKind } from 'mod-arch-shared';
export declare const modelRegistryColumns: SortableData<ModelRegistryKind>[];
