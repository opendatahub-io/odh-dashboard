import * as React from 'react';
type RegisteredModelsTableToolbarProps = {
    toggleGroupItems?: React.ReactNode;
    onClearAllFilters?: () => void;
};
declare const RegisteredModelsTableToolbar: React.FC<RegisteredModelsTableToolbarProps>;
export default RegisteredModelsTableToolbar;
