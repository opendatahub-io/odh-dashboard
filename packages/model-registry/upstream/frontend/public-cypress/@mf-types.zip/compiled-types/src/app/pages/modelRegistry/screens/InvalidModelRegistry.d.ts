import * as React from 'react';
type InvalidModelRegistryProps = {
    title?: string;
    modelRegistry?: string;
};
declare const InvalidModelRegistry: React.FC<InvalidModelRegistryProps>;
export default InvalidModelRegistry;
