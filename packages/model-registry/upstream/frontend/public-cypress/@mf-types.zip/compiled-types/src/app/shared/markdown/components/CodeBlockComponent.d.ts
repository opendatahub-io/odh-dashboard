import React from 'react';
type CodeBlockComponentProps = {
    children: React.ReactNode;
    className?: string;
};
declare const CodeBlockComponent: React.FC<CodeBlockComponentProps>;
export default CodeBlockComponent;
