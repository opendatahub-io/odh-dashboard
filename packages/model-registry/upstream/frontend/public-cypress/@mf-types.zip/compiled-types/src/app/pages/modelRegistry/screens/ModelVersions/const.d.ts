export declare enum ModelVersionsTab {
    OVERVIEW = "overview",
    VERSIONS = "versions"
}
export declare enum ModelVersionsTabTitle {
    OVERVIEW = "Overview",
    VERSIONS = "Versions"
}
