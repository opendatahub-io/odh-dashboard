import * as React from 'react';
type ModelCatalogLabelsProps = {
    tasks?: string[];
    license?: string;
    provider?: string;
};
declare const ModelCatalogLabels: React.FC<ModelCatalogLabelsProps>;
export default ModelCatalogLabels;
