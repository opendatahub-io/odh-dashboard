import React from 'react';
import { ModelVersion } from '~/app/types';
export declare const MRDeployButton: ({ mv }: {
    mv: ModelVersion;
}) => React.JSX.Element;
