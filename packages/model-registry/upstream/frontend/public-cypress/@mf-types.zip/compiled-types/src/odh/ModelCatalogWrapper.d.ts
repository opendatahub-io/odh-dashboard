import React from 'react';
declare const ModelCatalogWrapper: React.FC;
export default ModelCatalogWrapper;
