import * as React from 'react';
type ModelCatalogCoreLoaderrProps = {
    getInvalidRedirectPath: (sourceId: string) => string;
};
declare const ModelCatalogCoreLoader: React.FC<ModelCatalogCoreLoaderrProps>;
export default ModelCatalogCoreLoader;
