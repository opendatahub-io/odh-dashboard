import { GroupKind } from 'mod-arch-shared';
export declare const useGroups: (queryParams?: Record<string, unknown>) => [GroupKind[], boolean, Error | undefined];
