import React from 'react';
type LinkComponentProps = {
    children: React.ReactNode;
    href?: string;
    className?: string;
};
declare const LinkComponent: React.FC<LinkComponentProps>;
export default LinkComponent;
