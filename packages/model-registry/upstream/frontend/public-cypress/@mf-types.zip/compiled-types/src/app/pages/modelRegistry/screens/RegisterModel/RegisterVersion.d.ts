import React from 'react';
declare const RegisterVersion: React.FC;
export default RegisterVersion;
