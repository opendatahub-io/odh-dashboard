import React from 'react';
type DetailsComponentProps = {
    children: React.ReactNode;
    summary: string;
    className?: string;
};
declare const DetailsComponent: React.FC<DetailsComponentProps>;
export default DetailsComponent;
