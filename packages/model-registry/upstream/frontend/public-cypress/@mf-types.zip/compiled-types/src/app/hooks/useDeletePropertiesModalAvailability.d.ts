declare const useDeletePropertiesModalAvailability: () => [boolean, (v: boolean) => void];
export default useDeletePropertiesModalAvailability;
