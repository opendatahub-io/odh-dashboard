import React from 'react';
declare const ModelRegistriesPermissions: React.FC;
export default ModelRegistriesPermissions;
