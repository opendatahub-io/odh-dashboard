import React from 'react';
type ModelTimestampProps = {
    timeSinceEpoch?: string;
};
declare const ModelTimestamp: React.FC<ModelTimestampProps>;
export default ModelTimestamp;
