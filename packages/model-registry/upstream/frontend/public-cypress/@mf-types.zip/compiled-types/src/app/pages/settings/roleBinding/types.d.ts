export declare enum RoleBindingPermissionsRBType {
    USER = "User",
    GROUP = "Group"
}
export declare enum RoleBindingPermissionsRoleType {
    EDIT = "edit",
    ADMIN = "admin",
    DEFAULT = "default",
    CUSTOM = "custom"
}
