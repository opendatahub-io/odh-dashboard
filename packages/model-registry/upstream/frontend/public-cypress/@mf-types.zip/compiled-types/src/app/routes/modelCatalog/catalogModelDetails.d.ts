import { CatalogModelDetailsParams } from '~/app/modelCatalogTypes';
export declare const getCatalogModelDetailsRoute: (params: CatalogModelDetailsParams) => string;
