import * as React from 'react';
type ExternalLinkProps = {
    text: string;
    to: string;
    testId?: string;
};
declare const ExternalLink: React.FC<ExternalLinkProps>;
export default ExternalLink;
