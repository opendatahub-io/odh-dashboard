import * as React from 'react';
declare const ModelRegistryRoutes: React.FC;
export default ModelRegistryRoutes;
