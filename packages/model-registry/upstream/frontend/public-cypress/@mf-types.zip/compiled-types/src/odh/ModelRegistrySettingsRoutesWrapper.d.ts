import React from 'react';
declare const ModelRegistryWrapper: React.FC;
export default ModelRegistryWrapper;
