export declare const getRegisterCatalogModelRoute: (id?: string, name?: string) => string;
