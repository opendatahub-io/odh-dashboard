import type { NavExtension, RouteExtension, AreaExtension } from '@odh-dashboard/plugin-core/extension-points';
declare const extensions: (NavExtension | RouteExtension | AreaExtension)[];
export default extensions;
