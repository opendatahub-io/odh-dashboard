import * as React from 'react';
declare const ModelCatalogRoutes: React.FC;
export default ModelCatalogRoutes;
