import * as React from 'react';
declare const ModelCatalog: React.FC;
export default ModelCatalog;
