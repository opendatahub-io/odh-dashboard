import * as React from 'react';
type CreateModalProps = {
    onClose: () => void;
    refresh: () => void;
};
declare const CreateModal: React.FC<CreateModalProps>;
export default CreateModal;
