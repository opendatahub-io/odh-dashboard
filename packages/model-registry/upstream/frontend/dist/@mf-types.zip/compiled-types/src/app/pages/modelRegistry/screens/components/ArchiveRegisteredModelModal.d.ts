import * as React from 'react';
interface ArchiveRegisteredModelModalProps {
    onCancel: () => void;
    onSubmit: () => void;
    registeredModelName: string;
}
export declare const ArchiveRegisteredModelModal: React.FC<ArchiveRegisteredModelModalProps>;
export {};
