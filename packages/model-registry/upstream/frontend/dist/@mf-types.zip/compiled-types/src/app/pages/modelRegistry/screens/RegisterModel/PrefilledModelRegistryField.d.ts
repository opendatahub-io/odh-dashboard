import React from 'react';
type PrefilledModelRegistryFieldProps = {
    mrName?: string;
};
declare const PrefilledModelRegistryField: React.FC<PrefilledModelRegistryFieldProps>;
export default PrefilledModelRegistryField;
