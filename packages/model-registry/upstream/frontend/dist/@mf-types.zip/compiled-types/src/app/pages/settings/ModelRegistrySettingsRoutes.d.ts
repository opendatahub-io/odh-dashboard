import * as React from 'react';
declare const ModelRegistrySettingsRoutes: React.FC;
export default ModelRegistrySettingsRoutes;
