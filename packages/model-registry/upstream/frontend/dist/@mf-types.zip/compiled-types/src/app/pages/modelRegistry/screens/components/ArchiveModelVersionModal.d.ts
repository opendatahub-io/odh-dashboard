import * as React from 'react';
interface ArchiveModelVersionModalProps {
    onCancel: () => void;
    onSubmit: () => void;
    modelVersionName: string;
}
export declare const ArchiveModelVersionModal: React.FC<ArchiveModelVersionModalProps>;
export {};
