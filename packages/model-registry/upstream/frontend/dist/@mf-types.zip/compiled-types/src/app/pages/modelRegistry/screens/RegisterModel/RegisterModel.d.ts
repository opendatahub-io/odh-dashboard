import React from 'react';
declare const RegisterModel: React.FC;
export default RegisterModel;
