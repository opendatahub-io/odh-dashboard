import * as React from 'react';
declare const ResourceNameDefinitionTooltip: React.FC;
export default ResourceNameDefinitionTooltip;
