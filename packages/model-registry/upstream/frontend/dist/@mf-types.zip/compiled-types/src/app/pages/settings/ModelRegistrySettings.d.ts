import React from 'react';
declare const ModelRegistrySettings: React.FC;
export default ModelRegistrySettings;
