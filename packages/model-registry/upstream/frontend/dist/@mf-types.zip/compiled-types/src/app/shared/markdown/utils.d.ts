import { ContentVariants } from '@patternfly/react-core';
export declare const shiftHeadingLevel: (level: number, maxHeading: number) => ContentVariants;
