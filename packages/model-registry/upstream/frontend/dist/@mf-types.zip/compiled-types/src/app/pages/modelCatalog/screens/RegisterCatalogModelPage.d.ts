import * as React from 'react';
declare const RegisterCatalogModelPage: React.FC;
export default RegisterCatalogModelPage;
