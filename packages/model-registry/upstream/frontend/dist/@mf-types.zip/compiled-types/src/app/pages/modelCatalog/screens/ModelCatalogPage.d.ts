import React from 'react';
type ModelCatalogPageProps = {
    searchTerm: string;
};
declare const ModelCatalogPage: React.FC<ModelCatalogPageProps>;
export default ModelCatalogPage;
