import * as React from 'react';
type ModelRegistryCoreLoaderProps = {
    getInvalidRedirectPath: (modelRegistry: string) => string;
};
declare const ModelRegistryCoreLoader: React.FC<ModelRegistryCoreLoaderProps>;
export default ModelRegistryCoreLoader;
