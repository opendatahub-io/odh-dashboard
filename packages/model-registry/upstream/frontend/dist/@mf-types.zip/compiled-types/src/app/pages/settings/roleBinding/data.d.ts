import { RoleBindingKind, SortableData } from 'mod-arch-shared';
export declare const columnsRoleBindingPermissions: SortableData<RoleBindingKind>[];
