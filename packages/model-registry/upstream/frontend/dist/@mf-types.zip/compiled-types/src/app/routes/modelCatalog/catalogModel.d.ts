export declare const modelCatalogUrl: (sourceId?: string) => string;
export declare const catalogModelDetailsFromModel: (catalogModelName?: string, sourceId?: string) => string;
