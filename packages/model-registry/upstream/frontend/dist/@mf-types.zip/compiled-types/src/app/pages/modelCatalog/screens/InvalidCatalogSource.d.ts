import React from 'react';
type InvalidCatalogSourceProps = {
    title?: string;
    sourceId?: string;
};
declare const InvalidCatalogSource: React.FC<InvalidCatalogSourceProps>;
export default InvalidCatalogSource;
