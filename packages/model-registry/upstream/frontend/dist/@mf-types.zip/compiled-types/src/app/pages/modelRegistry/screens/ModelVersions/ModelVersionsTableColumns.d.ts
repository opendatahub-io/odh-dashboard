import { SortableData } from 'mod-arch-shared';
import { ModelVersion } from '~/app/types';
export declare const mvColumns: SortableData<ModelVersion>[];
