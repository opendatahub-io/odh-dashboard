export declare enum ModelVersionDetailsTab {
    DETAILS = "details"
}
export declare enum ModelVersionDetailsTabTitle {
    DETAILS = "Details"
}
