import { NamespaceKind } from '~/app/shared/components/types';
export declare const useNamespaces: () => [NamespaceKind[], boolean, Error | undefined];
