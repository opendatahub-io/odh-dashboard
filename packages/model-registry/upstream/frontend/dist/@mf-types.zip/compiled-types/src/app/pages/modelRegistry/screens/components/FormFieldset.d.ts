import React, { ReactNode } from 'react';
interface FormFieldsetProps {
    component: ReactNode;
    field?: string;
    className?: string;
}
declare const FormFieldset: React.FC<FormFieldsetProps>;
export default FormFieldset;
