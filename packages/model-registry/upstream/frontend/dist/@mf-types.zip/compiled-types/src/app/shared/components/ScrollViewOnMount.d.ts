import * as React from 'react';
type ScrollViewOnMountProps = {
    shouldScroll: boolean;
};
declare const ScrollViewOnMount: React.FC<ScrollViewOnMountProps>;
export default ScrollViewOnMount;
