import { SortableData } from 'mod-arch-shared';
import { RegisteredModel } from '~/app/types';
export declare const rmColumns: SortableData<RegisteredModel>[];
