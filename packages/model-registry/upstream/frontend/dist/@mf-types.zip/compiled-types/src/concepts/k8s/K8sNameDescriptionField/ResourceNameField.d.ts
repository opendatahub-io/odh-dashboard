import * as React from 'react';
type ResourceNameFieldProps = {
    allowEdit: boolean;
    dataTestId: string;
};
/** Sub-resource; not for public consumption */
declare const ResourceNameField: React.FC<ResourceNameFieldProps>;
export default ResourceNameField;
