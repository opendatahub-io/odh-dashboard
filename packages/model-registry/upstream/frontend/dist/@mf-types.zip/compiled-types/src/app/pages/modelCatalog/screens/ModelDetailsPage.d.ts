import React from 'react';
declare const ModelDetailsPage: React.FC;
export default ModelDetailsPage;
